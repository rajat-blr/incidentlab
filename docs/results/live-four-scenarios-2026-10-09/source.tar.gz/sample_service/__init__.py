"""Deterministic checkout incident fixture."""
