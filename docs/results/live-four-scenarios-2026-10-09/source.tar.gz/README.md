# IncidentLab

[![CI](https://github.com/rajat-blr/incidentlab/actions/workflows/ci.yml/badge.svg)](https://github.com/rajat-blr/incidentlab/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

IncidentLab is an evidence-backed incident investigation and repair-verification
system. It reproduces a failure, gathers attributable telemetry and source
context, produces a structured diagnosis, and verifies a proposed repair inside
an isolated sandbox.

The project explores a practical question: **how can an AI-assisted incident
workflow remain useful without allowing the model to become the source of
truth?**

IncidentLab keeps collection, approval, policy enforcement, and verification
outside the model. The model can explain evidence and propose a bounded change;
deterministic controls decide what is accepted.

## Live demo

### [Launch IncidentLab →](https://incidentlab-flax.vercel.app/runs)

The deployed experience runs entirely from curated saved investigation data. It
does not require an account, backend service, or API key.

## What the demo shows

The browser-only demo contains seven investigation histories with successful,
failed, inconclusive, closed, and cancelled outcomes. It also lets a visitor
start a guided replay for either supported incident:

- **Pool exhaustion** — rejected checkout requests leak database connections
  until a valid request times out.
- **Inventory underflow** — an oversized checkout bypasses the stock guard and
  commits a negative inventory quantity.

A guided replay moves through reproduction, evidence collection, diagnosis,
human approval, repair generation, and verification using curated saved data.

### Review console

Evidence citations beside a diagnosis:

![Diagnosis with supporting trace, metric, and log citations](docs/images/citations.png)

The approval checkpoint before repair generation:

![Approval checkpoint in the guided replay](docs/images/approval.png)

These screenshots show the browser-only guided demo with curated data. They
illustrate the UI; measured live-model results are reported separately below.

## Live-model results

Measured on 2026-10-09 with `gpt-5.4-mini`, prompts `diagnosis-v2` and `repair-v7`,
against commit `a8c1bd576f633b6c0202b5cc68918874ae575053`. Each model trial uses
real telemetry, structured model output, deterministic policy, and Docker
verification. Approval is recorded by the automated evaluator.

| Batch / scenario | Attempts | Reproduction | Valid cited diagnosis¹ | Verified repair | Failures |
| --- | ---: | ---: | ---: | ---: | ---: |
| Model trials: pool exhaustion | 3 | 3/3 (100%) | 2/3 (66.7%) | 2/3 (66.7%) | 1 |
| Model trials: inventory underflow | 3 | 3/3 (100%) | 3/3 (100%) | 3/3 (100%) | 0 |
| **Model batch** | **6** | **6/6 (100%)** | **5/6 (83.3%)** | **5/6 (83.3%)** | **1** |
| Earlier batch: authentication failures | 6 | 6/6 (100%) | 0/6 (0%) | 0/6 (0%) | 6 |
| **All attempts, both batches** | **12** | **12/12 (100%)** | **5/12 (41.7%)** | **5/12 (41.7%)** | **7** |

The model-batch failure exceeded the diagnosis follow-up query budget. The
earlier six attempts failed provider authentication and produced no model
output. Both batches are retained; no failed trials are dropped.

¹Citation validity here is a **trial success rate**: every citation must resolve,
no gap may support a hypothesis, and cited artifacts must pass SHA-256 checks.
Across emitted hypotheses, **33/33 citation IDs resolved**; this checks integrity,
not whether the evidence semantically proves the diagnosis.

See the [model-batch report](docs/results/live-2026-10-09-rerun/report.json),
[failure](docs/results/live-2026-10-09-rerun/failures.json),
[raw artifact manifest](docs/results/live-2026-10-09-rerun/artifact-manifest.json),
[earlier authentication failures](docs/results/live-2026-10-09/failures.json), and
[methodology and rerun command](docs/evaluation.md). This is a small pilot on
two defects in one service; it does not establish cross-service performance.

## Investigation pipeline

```text
Reproduce incident
       │
       ▼
Collect traces, metrics, logs, and pinned source
       │
       ▼
Generate evidence-cited diagnosis
       │
       ▼
Human approval checkpoint
       │
       ▼
Generate bounded repair candidate
       │
       ▼
Apply deterministic repair policy
       │
       ▼
Verify in an isolated Docker sandbox
       │
       ▼
Persist facts, audit history, and report
```

The final result is derived from fixed verification checks—not from a model
claiming that its own repair worked.

## System architecture

```text
Sample checkout service
   ├── traces ─── Jaeger ──────┐
   ├── metrics ─ Prometheus ───┼── Evidence collector
   └── logs ──── Loki ─────────┘          │
                                          ▼
React console ─ FastAPI ─ PostgreSQL ─ Temporal workflow
                                          │
                                   OpenAI adapters
                                          │
                                   Repair policy
                                          │
                                          ▼
                           Trusted verifier ─ Docker sandbox
```

The API and model worker never receive the Docker socket. A separate trusted
verifier owns sandbox execution and records check results before the workflow
derives its terminal state.

## Core design choices

### Evidence before explanation

Every diagnosis citation must resolve to stored evidence. Missing telemetry is
recorded as an explicit gap rather than silently ignored.

### Human-controlled repair generation

Diagnosis is separated from repair. A reviewer must explicitly approve repair
generation, and rejection closes the investigation without producing a patch.

### Fail-closed repair policy

Model output is converted into a deterministic unified diff against a pinned
commit. Path, size, secret, syntax, and clean-application checks run before a
candidate can reach verification.

### Independent verification

Candidates run in a network-disabled, non-root container with resource limits.
Baseline reproduction, compilation, static analysis, unit tests, integration
tests, and repeated incident replay are stored as hash-verified facts.

### Durable and inspectable execution

Temporal provides retry-safe orchestration. PostgreSQL stores investigation
state, evidence, model usage, decisions, verification results, and the audit
trail exposed by the review console.

## Technology

| Area | Technology |
| --- | --- |
| Frontend | React, TypeScript, Vite, TanStack Query |
| API | FastAPI, SQLAlchemy, Alembic |
| Workflow | Temporal |
| Storage | PostgreSQL |
| Observability | OpenTelemetry, Jaeger, Prometheus, Loki |
| Model integration | OpenAI Structured Outputs |
| Verification | Docker sandbox with fixed checks |
| Local environment | Docker Compose, uv |

## Build and run from source

### Prerequisites

- Docker Desktop with Docker Compose v2
- Git
- An OpenAI API key

Clone the repository and enter its root directory:

```sh
git clone https://github.com/rajat-blr/incidentlab.git
cd incidentlab
```

Cloning is preferred because IncidentLab uses the repository's `.git` metadata
to pin each investigation to an exact commit. If you downloaded a GitHub source
archive instead, initialize it once before continuing:

```sh
git init
git add .
git commit -m "Initialize local IncidentLab source"
```

Create the local environment file:

```sh
cp .env.example .env
```

Set `OPENAI_API_KEY` in `.env`. Keep this file private; it is ignored by Git.
The default model is already configured as `gpt-5.4-mini`.

With Docker Desktop running, build and start the complete application:

```sh
docker compose up --build -d --wait
```

This builds the API, workflow worker, frontend, verifier, and verification
sandbox; starts PostgreSQL, Temporal, and the telemetry services; and applies
the database migrations. Open `http://localhost:5173` to use the application.

Useful lifecycle commands:

```sh
# Follow application and verification logs
docker compose logs -f api worker verifier

# Stop the stack while preserving its database volumes
docker compose down
```

## Repository map

```text
incidentlab/       API, workflows, persistence, evidence, policy, and verification
frontend/          React review console, guided replay, and saved demo data
sample_service/    Fault-injected checkout service and replay utilities
scenarios/         Public scenario definitions and private evaluation truth
telemetry/         Collector, Prometheus, and Loki configuration
migrations/        Database migrations
scripts/           Evaluation and operational utilities
tests/             Backend test suite
docs/              Architecture, threat model, sandbox, and evaluation notes
```

Local PRDs and `work/` design scratch files are ignored and untracked.

## Optional GitHub integration

The backend validates signed GitHub App installation webhooks. After a repair
passes verification, a separately approved CLI action can create or retrieve a
draft PR on a deterministic branch. This feature is opt-in and requires an
installation token; it is not part of the browser-only demo. See
[setup, permissions, and draft PR workflow](docs/github-integration.md).

## Development checks

Pull requests and pushes to `main` run backend lint and unit tests, the offline
regression evaluation, frontend tests, and both live and demo frontend builds.
The [CI workflow](.github/workflows/ci.yml) does not need an API key. The separate
[release workflow](.github/workflows/publish-containers.yml) publishes container
images for version tags or manual dispatch.

## License

[MIT](LICENSE), copyright 2026 IncidentLab contributors.

## Further reading

- [Architecture](docs/architecture.md)
- [Threat model](docs/threat-model.md)
- [Sandbox boundary](docs/sandbox.md)
- [Evaluation methodology](docs/evaluation.md)
- [Failure modes](docs/failure-modes.md)
- [GitHub integration](docs/github-integration.md)
- [Container releases](docs/container-release.md)

## Scope

IncidentLab is a portfolio and educational system built around controlled,
deterministic scenarios. It is not a production incident-response platform, and
the sandbox should not be treated as a hardened boundary for arbitrary untrusted
repositories.

Both supported scenarios target the same checkout service. Results measure
these two controlled defects only; they do not establish performance across
unfamiliar services, repositories, or incident classes.
